# Smart Todo Local Service — Part 1A

A loopback-only task API for the BITS Pilani Assignment 1 Part 1A. This is a local Node.js REST service with JSON-file persistence and an independent deterministic HTTP harness. It was created in the student folder requested for this project; no GitHub repository or remote is configured.

## Prerequisites

- Windows PowerShell
- Node.js 24
- pnpm 11.25.0 (the lockfile pins project dependencies)
- Internet access only when installing pinned development tools or retrieving the explicit Semgrep JavaScript ruleset

The application itself uses Node.js built-ins and has no runtime package dependencies. ESLint and Semgrep are separate development checks.

## Install

From this folder:

```powershell
pnpm install --frozen-lockfile
```

The project stores pnpm packages in `.pnpm-store` and uses the hoisted linker to avoid Windows symlink requirements.

## Run the service

```powershell
pnpm start
```

The service binds to `127.0.0.1` on port `3000`. It writes task data to `data/tasks.json` by default. Set a trusted local file path before starting to use another location:

```powershell
$env:SMART_TODO_DATA_FILE = (Join-Path (Get-Location) 'data\my-tasks.json')
pnpm start
```

The port can also be selected with the local `PORT` environment variable. The service accepts `0` to ask Windows for an available port and prints the selected loopback URL on startup. Request data cannot select the storage path.

## HTTP API

All responses are JSON. The API binds only to loopback.

| Method and path | Behavior |
|---|---|
| `POST /tasks` | Create a task; title and priority are required. |
| `GET /tasks` | List tasks by ID ascending. |
| `GET /tasks?tag=home&tag=work&sort=priority` | Filter by every selected tag and optionally sort by `now`, `next`, `later`, then ID. |
| `GET /tasks/{id}` | Retrieve one task. |
| `PATCH /tasks/{id}` | Change title, notes, priority, or tags. |
| `DELETE /tasks/{id}` | Delete a task. |
| `PATCH /tasks/{id}/status` | Apply one allowed task status transition. |

Valid priorities are `now`, `next`, and `later`. Statuses follow `queued → active → blocked → active`, with `active → done`; `done` is terminal. Invalid input, unknown IDs, invalid transitions, oversized bodies, and storage errors return stable JSON error codes. The request body limit is 65,536 bytes.

## Validate

Run each check separately:

```powershell
pnpm test
pnpm harness
pnpm lint
pnpm sast
```

The harness starts the app as a child process, calls only its loopback HTTP API, and gives each case an isolated temporary data file. It does not import application modules. Its 100-task performance case measures the filtered/sorted request and checks the approved one-second limit.

`pnpm sast` pins Semgrep Community Edition 1.185.0 and the explicit `p/javascript` ruleset. On this Windows host, the regular CLI JSON formatter exits with a Semgrep Core RPC `socketpair` error. The script preserves that failed CLI output, then runs the same generated rules and six `src/*.mjs` targets through the bundled Semgrep Core with `-json_nodots` and the legacy single-job `parmap` scheduler. The final raw engine JSON, CLI failure, scanner/rules metadata, and status are under `evidence/part-1a/raw/`. The recorded fallback run executed 68 rules with zero findings and zero engine errors. This is a local static-analysis result, not a claim that the standard CLI JSON formatter succeeded.

## Evidence and student-authored sections

Machine outputs and both source-generation archives are under `evidence/part-1a/`. The initial archive is separate from the final archive, and each archive has a SHA-256 manifest. `evidence/part-1a/harness-log.md` is intentionally blank apart from its scaffold; the student fills it in after reviewing the raw evidence. No reflection answers or human ACCEPT/REJECT decision are generated here.

Spec Kit artifacts for this application are in `specs/001-smart-todo-api/`.
