$ErrorActionPreference = "Stop"
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$rawDirectory = Join-Path $projectRoot "evidence\part-1a\raw"
New-Item -ItemType Directory -Force -Path $rawDirectory | Out-Null
$uvxCommand = Get-Command uvx -ErrorAction SilentlyContinue
if ($uvxCommand) {
    $uvx = $uvxCommand.Source
} else {
    $uvx = Join-Path $projectRoot ".tools\bootstrap\Scripts\uvx.exe"
}
if (-not (Test-Path $uvx)) {
    throw "uvx was not found. Install uv and make uvx available on PATH."
}
$env:UV_CACHE_DIR = Join-Path $projectRoot ".tools\uv-cache"
$semgrepPin = "semgrep==1.185.0"
$ruleset = "p/javascript"
$rawResults = Join-Path $rawDirectory "sast.json"
$metadataPath = Join-Path $rawDirectory "sast-metadata.json"
$statusPath = Join-Path $rawDirectory "sast-status.json"
$startedAt = [DateTime]::UtcNow.ToString("o")
$versionLines = & $uvx --from $semgrepPin semgrep --version 2>&1
$versionExit = $LASTEXITCODE
$version = ($versionLines | Select-Object -Last 1).ToString().Trim()
if ($versionExit -ne 0) {
    $status = [ordered]@{ command = "uvx --from $semgrepPin semgrep --version"; exitCode = $versionExit; passed = $false; reason = "Semgrep version command failed" }
    $status | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 $statusPath
    exit $versionExit
}
& $uvx --from $semgrepPin semgrep scan --config $ruleset --json --output $rawResults src
$scanExit = $LASTEXITCODE
$findings = -1
$errors = -1
if (Test-Path $rawResults) {
    $report = Get-Content -Raw $rawResults | ConvertFrom-Json
    $findings = @($report.results).Count
    $errors = @($report.errors).Count
}
$metadata = [ordered]@{
    scanner = "Semgrep Community Edition"
    version = $version
    package = $semgrepPin
    ruleset = $ruleset
    scannedPath = "src"
    startedAtUtc = $startedAt
    finishedAtUtc = [DateTime]::UtcNow.ToString("o")
}
$metadata | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 $metadataPath
$passed = ($scanExit -eq 0 -and $findings -eq 0 -and $errors -eq 0)
$status = [ordered]@{
    command = "uvx --from $semgrepPin semgrep scan --config $ruleset --json --output evidence/part-1a/raw/sast.json src"
    exitCode = $scanExit
    findingCount = $findings
    errorCount = $errors
    passed = $passed
}
$status | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 $statusPath
if (-not $passed) { exit 1 }
exit 0
